/*
 * lcd and button.c
 *
 * Created: 4/23/2022 6:15:58 PM
 * Author : Charith Eranga
 */ 

#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdio.h>
#include <avr/interrupt.h>
#include "button.h"
#include "lcd_ce.h"
#include "Ultrasonic_distance.h"
#include "dryfan.h"


int other_polish_level();
int black_polish_level();
int color_Detection();


int main()
{
	lcd_init();

	lcd_cmd(0x01);
	lcd_cmd(0x80);	//1st row
	lcd_str("1. Quick START");
	lcd_cmd(0xC0);  //2nd row
	lcd_str("2. Setting");
	
	int interface=1;
	int black,other,color;
	int fspeed=0,size= maxShoe();
	black=black_polish_level();
	other=other_polish_level();
	color=color_Detection();
	
	while (1)
	{		
		//black=black_polish_level();
		//other=other_polish_level();
		
		//button
		if (PINA==(1<<4))   //quick start
		{
			if (color==1)
			{
				lcd_cmd(0x01);  //clear display
				lcd_rc(1,1);
				lcd_str("Black Colour");
				lcd_rc(2,1);
				lcd_str("Detected");
				_delay_ms(50);
				
				if (black==1)
				{
					//dryfan();
				}else{
					lcd_cmd(0x01);  //clear display
					lcd_rc(1,1);
					lcd_str("polish level low");
					_delay_ms(50);
				}
			}
			else{
				lcd_cmd(0x01);  //clear display
				lcd_rc(1,1);
				lcd_str("Other Colour");
				lcd_rc(2,1);
				lcd_str("Detected");
				_delay_ms(50);
			}
			//dryfan();
			mainscr(black,other);   //polish level
			
			//check karala hari nam palleha code eka thiyanna ona(welawa wenas karanawa nm eke code ekath methanata daanna ona)
			//moter wala code ekath methanata danna ona
			lcd_cmd(0x01);
			lcd_cmd(0x80);	//1st row
			lcd_str("Machine Status :");
			lcd_cmd(0xC0);  //2nd row
			lcd_str("Polishing");
			_delay_ms(300);
		}
		
		else if (PINA==(1<<5))	//Menu	
		{
			if (interface == 1){
				info(size,color); //mekata code eka liyanna ona
				_delay_ms(50);
				interface=2;
			}
			else if (interface==2)
			{
				mainscr(black,other); // level eke code eka hari
				interface=3;
				_delay_ms(50);
			}
			else if (interface==3)
			{
				fanscr(fspeed);		//speed eke code eka liyanna ona
				_delay_ms(50);
				int select=0;
				while (select==0)
				{
					if(PINA==(1<<7))  //high
					{
						select=0; // high speed eke code eka liyanna ona
						fspeed=1;
						fanscr(fspeed);
						_delay_ms(50);
					}
					else if (PINA==(1<<6)) //low
					{
						select=0; // low speed eke code eka liyanna ona
						fspeed=0;
						fanscr(fspeed);
						_delay_ms(50);
					}
					else if (PINA==(1<<4))   //save button
					{
						select=1;		 
						updated();
						_delay_ms(50);
					}
					else if (PINA==(1<<5)) //exit without saving
					{
						interface=1;
						select=1;
					}
				}
				interface=1;
			}
		}
	}
}


//polish level eka display karana code eka.
int black_polish_level(){
	int black;
	DDRB = DDRB &(~(1<<2))&(~(1<<1));
	
	if((PINB & (1<<1))!=0){
		black=1;
	}
	else{  // me code tika udata yawanna ona
		lcd_cmd(0x01);
		lcd_cmd(0x80);	//1st row
		lcd_str("Polish level low");
		lcd_cmd(0xC0);
		lcd_str("Black");
		_delay_ms(50);
		black=0;
	}
	return black;
}

int other_polish_level(){
	int other;
	DDRB = DDRB &(~(1<<2))&(~(1<<1));
	
	if((PINB & (1<<2))!=0){
		other=1;
	}
	else{  // me code tika udata yawanna ona
		lcd_cmd(0x01);
		lcd_cmd(0x80);	//1st row
		lcd_str("Polish level low");
		lcd_cmd(0xC0);
		lcd_str("Other");
		_delay_ms(50);
		other=0;
	}
	return other;
}

//shoe color detection
int color_Detection()
{
	DDRB = DDRB &(~(1<<0));
	int black_shoes=0;
	int color_select=0;
	int pin_value=PINB & (1<<0);
	
	if (pin_value==1)
	{
		black_shoes=1;
	}
	if (pin_value!=1)
	{		
		lcd_cmd(0x01);  //clear display
		lcd_rc(1,1);
		lcd_str("Choose correct");
		lcd_rc(2,1);
		lcd_str("colour:");
		//_delay_ms(100);
		while (color_select==0)
		{
			if (PINA ==(1<<6))
			{
				black_shoes=1;
				lcd_rc(2,9);
				lcd_str(" Black");
				color_select=1;
			}
			else if (PINA ==(1<<7))
			{
				black_shoes=0;
				lcd_rc(2,9);
				lcd_str(" Other");
				color_select=1;
			}
			else if (PINA==(1<<4))   //save button
			{
				color_select=1;
				updated();
				_delay_ms(100);
				break;
			}
			color_select=0;
		}
	}
	return black_shoes;
}

